#!/bin/bash
for file in *.plist 
do 
	echo $file
	plutil -convert json -e json $file
done
